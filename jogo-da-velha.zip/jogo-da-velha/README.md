# Jogo da Velha

Projeto produzido para um bootcamp em parceria com a [Digital Innovation One](https://digitalinnovation.one).

# Descrição do projeto
Neste projeto, desenvolvemos juntos um jogo da velha utilizando HTML, CSS e Javascript.

## Para rodar o projeto

Para executarmos o projeto, basta apenas abrir o arquivo index.html em um navegador de preferência.

## Links

[PPT utilizado](https://docs.google.com/presentation/d/1-ao-3echbBHzdSqRF726K4GUFMn7JoL0dhoJWyPORXY/edit?usp=sharing)